-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 07, 2021 at 06:39 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gabbbbbage`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `password` text NOT NULL,
  `ucat` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `contact` varchar(500) NOT NULL,
  `acstatus` varchar(500) NOT NULL,
  `date` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `fullname`, `password`, `ucat`, `address`, `contact`, `acstatus`, `date`, `image`) VALUES
(7, 'shree', 'shreeyesh', 'muna', 'collector', 'Banglore', '8861711154', 'active', '2021-06-22', 'Screenshot_20210321-205607.png'),
(8, 'sanjana', 'sanjana ', 'megu', 'admin', 'Banglore', '8904021054', 'active', '2021-06-22', 'Screenshot_20210324-113832.png'),
(9, 'mahesh', 'maheshk ', 'mahi', 'admin', 'Banglore', '8904021058', 'active', '2021-06-22', 'Screenshot_20210324-113832.png');
-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(500) NOT NULL,
  `pay_type` varchar(500) NOT NULL,
  `client_type` varchar(500) NOT NULL,
  `gabage_type` varchar(500) NOT NULL,
  `location` text NOT NULL,
  `contact` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `names`, `pay_type`, `client_type`, `gabage_type`, `location`, `contact`, `status`, `date`) VALUES
(25, 'prakash', 'percollection', 'individual', 'Bio Waste', 'tathaguni', '9035769835', 'Approved', '2022-06-23'),
(26, 'vaishnavi', 'weekly', 'company', 'Non Hazardous', 'kanakapura', '9731151076', 'Degrdable', '2022-04-14'),
(29, 'pranavi', 'monthly', 'individual', 'Hazardous', 'banglore', '9035751076', 'pending', '2022-06-24'),
(30, 'vineet', 'monthly', 'company', 'Non Hazardous', 'hubli', '9901220671', 'pending', '2021-06-18');

-- --------------------------------------------------------

--
-- Table structure for table `gabbage_type`
--

CREATE TABLE IF NOT EXISTS `gabbage_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `chargespm` text NOT NULL,
  `chargespd` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `gabbage_type`
--

INSERT INTO `gabbage_type` (`id`, `name`, `chargespm`, `chargespd`) VALUES
(10, 'Non Hazardous', '6000', '200'),
(11, 'Hazardous', '7500', '250'),
(12, 'Bio Waste', '5100', '170');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collector` text NOT NULL,
  `clientname` text NOT NULL,
  `typeofwaste` text NOT NULL,
  `paytype` text NOT NULL,
  `amountpaid` text NOT NULL,
  `date` text NOT NULL,
  `recieptno` text NOT NULL,
  `reason` text NOT NULL,
  `balance` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `collector`, `clientname`, `typeofwaste`, `paytype`, `amountpaid`, `date`, `recieptno`, `reason`, `balance`) VALUES
(1, 'suhas', 'prakash', 'Bio Waste', 'percollection', '5000', '2021-06-23', '100', 'payment for jan', '100'),
(2, 'bhanav', 'pranavi', 'Hazardous', 'monthly', '5000', '2021-06-23', '200', 'jan', '2500'),
(3, 'ajay', 'prakash', 'Bio Waste', 'percollection', '4000', '2021-06-24', '300', 'month', '1100'),
(4, 'ramya', 'vaishnavi', 'Non Hazardous', 'weekly', '1000', '2021-06-25', '400', 'week', '400');

-- --------------------------------------------------------

--
-- Table structure for table `wastecollect`
--

CREATE TABLE IF NOT EXISTS `wastecollect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collector` text NOT NULL,
  `clientname` text NOT NULL,
  `typeofwaste` text NOT NULL,
  `paytype` text NOT NULL,
  `amountpaid` text NOT NULL,
  `balance` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `wastecollect`
--

INSERT INTO `wastecollect` (`id`, `collector`, `clientname`, `typeofwaste`, `paytype`, `amountpaid`, `balance`, `date`) VALUES
(1, 'suhas', 'prakash', 'Bio Waste', 'percollection', '5000', '100', '2021-06-23'),
(2, 'bhanav', 'pranavi', 'Hazardous', 'monthly', '5000', '2500', '2021-06-23'),
(3, 'ajay', 'prakash', 'Bio Waste', 'per collection', '4000', '300', '2021-06-24'),
(4, 'ramya', 'vaishnavi', 'Non Hazardous', 'weekly', '1000', '400', '2021-06-25'),
(5, 'sindhu', 'vaishnavi', 'Non Hazardous', 'weekly', '1000', '400', '2021-06-23'),
(6, 'yesh', 'vineet', 'Non Hazardous', 'monthly', '10000', '2000', '2021-06-24'),
(7, 'anusha', 'vineet', 'Non Hazardous', 'monthly', '15000', '5000', '2021-06-25');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
