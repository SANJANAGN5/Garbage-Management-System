<?php 
  include 'connect.php';
    

$id=$_GET['id'];
$delete=mysqli_query($con,"delete from client where id='$id'");
if ($delete) {
	header("location:patients1.php");
   echo "deleted";
}
else{
 echo "not deleted".mysqli_error(0);

}

 ?>


