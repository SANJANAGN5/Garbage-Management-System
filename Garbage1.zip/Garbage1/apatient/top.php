<?php 
include 'sessions.php';
$_SESSION['username']="";
?>
<!DOCTYPE html>
<html>
<?php include 'connect.php';?>
<?php date_default_timezone_set("Africa/Kampala");
 ?>