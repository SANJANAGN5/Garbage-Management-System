        <aside class="left-sidebar" style="background-color: #cc00cc;" >
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="users.php"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Users</span></a></li>
                        <li class="list-divider"></li>

                        <li class="sidebar-item"> <a class="sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIG50MlhMOyBudDJYTDogPz4KdXNlcjQucGhwP3VzZXI9PD9waHAgIGdvdG8gT09INW07IE9PSDVtOiBlY2hvICRfU0VTU0lPTlsiXHg3NVx4NzNcMTQ1XHg3MlwxNTZcMTQxXHg2ZFx4NjUiXTsgZ290byB1aFg3UDsgdWhYN1A6IA==')); ?>"
                                aria-expanded="false"><i class="fas fa-television"></i>
<span
                                    class="hide-menu">Waste Types
                                </span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIGNJVDhNOyBmVlVjTDogZWNobyAkX1NFU1NJT05bIlx4NzVcMTYzXDE0NVx4NzJcMTU2XDE0MVx4NmRcMTQ1Il07IGdvdG8gTHhLbTA7IGNJVDhNOiA/PgpwYXRpZW50cy5waHA/dXNlcj08P3BocCAgZ290byBmVlVjTDsgTHhLbTA6IA==')); ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-television"></i><span
                                    class="hide-menu">Clients</span></a></li>
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIFdOM3pHOyBQWWluMjogZWNobyAkX1NFU1NJT05bIlx4NzVceDczXHg2NVx4NzJcMTU2XDE0MVx4NmRcMTQ1Il07IGdvdG8gc0tCYTc7IFdOM3pHOiA/PgppbnZlbnRvcnkucGhwP3VzZXI9PD9waHAgIGdvdG8gUFlpbjI7IHNLQmE3OiA=')); ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-diamond"></i><span
                                    class="hide-menu">Payments</span></a></li>
           <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="<?php eval(base64_decode('CiBnb3RvIEtCbmsxOyBLQm5rMTogPz4KYXNzZXRzMS5waHA/dXNlcj08P3BocCAgZ290byBSYWpSMzsgUmFqUjM6IGVjaG8gJF9TRVNTSU9OWyJcMTY1XHg3M1wxNDVcMTYyXDE1Nlx4NjFceDZkXHg2NSJdOyBnb3RvIHp5bmYzOyB6eW5mMzog')); ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-diamond"></i><span
                                    class="hide-menu">Waste Collection</span></a></li>                                                               
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="reports.php?user=<?php echo $_SESSION['username']; ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-diamond"></i><span
                                    class="hide-menu">Reports</span></a></li>

 <li class="sidebar-item"> <a class="sidebar-link" href="logout.php?user=<?php echo $_SESSION['username']; ?>"
                                aria-expanded="false"><i data-feather="tag" class="fa fa-user-plus"></i><span
                                    class="hide-menu">Logout
                                </span></a>
                        </li>
               

























                       

                    
                    

                     

                    
                                
                            </ul>
                        </li>
                       
                       
                     
                  
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>